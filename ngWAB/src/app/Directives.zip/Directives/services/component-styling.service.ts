import { Injectable, OnInit } from '@angular/core';
import { PageComponent } from 'src/app/Types/page-component';

@Injectable({
    providedIn: 'root'
})
export class ComponentStylingService implements OnInit {
    private component: PageComponent;

    constructor() {}

    ngOnInit() {
        this.component = {
            id: 1,
            comp: {
                id: 1,
                compName: 'button',
                compType: 'button',
                },
            page_id: 1,
            parent_id: 0,
            compTemplate: '<button>It Worked!!!</button>',
            compStyling: 'button{ color: blue }',
            x_cord: 0,
            y_cord: 0
        };
    }

    getComponent(): PageComponent {
        return this.component;
    }
}
